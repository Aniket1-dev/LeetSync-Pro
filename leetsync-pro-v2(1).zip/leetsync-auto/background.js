/**
 * LeetSync Pro — Background Script
 * Handles GitHub OAuth + auto-push logic
 */

const GITHUB_CLIENT_ID = "Ov23liABCDEFGHIJKLMN"; // User will replace with their own
const REDIRECT_URI = browser.identity.getRedirectURL();

const LANG_EXT = {
  cpp: "cpp", cplusplus: "cpp", java: "java", python: "py", python3: "py",
  javascript: "js", typescript: "ts", csharp: "cs", c: "c",
  ruby: "rb", swift: "swift", golang: "go", kotlin: "kt",
  rust: "rs", php: "php", mysql: "sql", kotlin: "kt",
};

// ── GitHub OAuth ──────────────────────────────────────────────────────────────

async function githubLogin() {
  const scope = "repo";
  const authUrl = `https://github.com/login/oauth/authorize?client_id=${GITHUB_CLIENT_ID}&redirect_uri=${encodeURIComponent(REDIRECT_URI)}&scope=${scope}`;

  try {
    const redirectUrl = await browser.identity.launchWebAuthFlow({
      url: authUrl,
      interactive: true,
    });

    const code = new URL(redirectUrl).searchParams.get("code");
    if (!code) throw new Error("No code in redirect");

    // Exchange code for token via our proxy
    // Since we can't expose client_secret in extension, we use GitHub's device flow instead
    return { ok: false, msg: "Use Personal Access Token instead (see popup)" };
  } catch (e) {
    return { ok: false, msg: e.message };
  }
}

// ── LeetCode cookie fetch ─────────────────────────────────────────────────────

async function getLeetCodeSession() {
  const cookies = await browser.cookies.getAll({ domain: "leetcode.com" });
  const session = cookies.find(c => c.name === "LEETCODE_SESSION");
  const csrf = cookies.find(c => c.name === "csrftoken");
  return {
    session: session?.value || null,
    csrf: csrf?.value || null,
  };
}

// ── LeetCode API ──────────────────────────────────────────────────────────────

async function fetchProblemInfo(titleSlug, session, csrf) {
  const body = JSON.stringify({
    query: `query($titleSlug:String!){question(titleSlug:$titleSlug){difficulty questionFrontendId title}}`,
    variables: { titleSlug },
  });

  const res = await fetch("https://leetcode.com/graphql/", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Cookie": `LEETCODE_SESSION=${session}; csrftoken=${csrf}`,
      "x-csrftoken": csrf,
      "Referer": "https://leetcode.com/",
    },
    body,
  });

  const data = await res.json();
  const q = data?.data?.question;
  return q ? { difficulty: q.difficulty, id: q.questionFrontendId, title: q.title } : null;
}

async function fetchLatestAcceptedCode(titleSlug, session, csrf) {
  const res = await fetch(`https://leetcode.com/api/submissions/?offset=0&limit=10`, {
    headers: {
      "Cookie": `LEETCODE_SESSION=${session}; csrftoken=${csrf}`,
      "x-csrftoken": csrf,
      "Referer": "https://leetcode.com/",
      "Accept": "application/json",
    },
  });

  if (!res.ok) return null;
  const data = await res.json();
  const subs = data?.submissions_dump || [];

  // Find latest accepted for this problem
  const match = subs.find(s => s.title_slug === titleSlug && s.status_display === "Accepted");
  return match?.code || null;
}

// ── GitHub API ────────────────────────────────────────────────────────────────

async function getGitHubToken() {
  const { githubToken } = await browser.storage.local.get("githubToken");
  return githubToken || null;
}

async function getRepoConfig() {
  const { githubUsername, githubRepo } = await browser.storage.local.get(["githubUsername", "githubRepo"]);
  return { username: githubUsername, repo: githubRepo };
}

async function pushToGitHub(token, username, repo, folder, filename, content, message) {
  const path = `${folder}/${filename}`;
  const apiUrl = `https://api.github.com/repos/${username}/${repo}/contents/${path}`;

  // Check existing file
  const checkRes = await fetch(apiUrl, {
    headers: {
      Authorization: `token ${token}`,
      Accept: "application/vnd.github.v3+json",
    },
  });
  const sha = checkRes.ok ? (await checkRes.json()).sha : null;

  // Push
  const res = await fetch(apiUrl, {
    method: "PUT",
    headers: {
      Authorization: `token ${token}`,
      "Content-Type": "application/json",
      Accept: "application/vnd.github.v3+json",
    },
    body: JSON.stringify({
      message,
      content: btoa(unescape(encodeURIComponent(content))),
      ...(sha ? { sha } : {}),
    }),
  });

  return res.status === 200 || res.status === 201;
}

async function ensureRepo(token, username, repo) {
  const res = await fetch(`https://api.github.com/repos/${username}/${repo}`, {
    headers: { Authorization: `token ${token}`, Accept: "application/vnd.github.v3+json" },
  });
  if (res.status === 404) {
    await fetch("https://api.github.com/user/repos", {
      method: "POST",
      headers: { Authorization: `token ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ name: repo, auto_init: true, private: false, description: "LeetCode solutions — Easy / Medium / Hard" }),
    });
  }
}

// ── Main sync handler ─────────────────────────────────────────────────────────

browser.runtime.onMessage.addListener(async (msg, sender) => {
  if (msg.type === "ACCEPTED_SOLUTION") {
    await handleSync(msg.payload, sender.tab);
  }
  if (msg.type === "TEST_CONNECTION") {
    return testConnection();
  }
  if (msg.type === "GET_STATUS") {
    return getStatus();
  }
});

async function handleSync({ titleSlug, code: pageCode, lang }) {
  const token = await getGitHubToken();
  if (!token) {
    showNotification("LeetSync: Not configured", "Open extension popup and add GitHub token.");
    return;
  }

  const { username, repo } = await getRepoConfig();
  if (!username || !repo) {
    showNotification("LeetSync: No repo set", "Open extension popup to configure.");
    return;
  }

  // Get LeetCode session from browser cookies automatically
  const { session, csrf } = await getLeetCodeSession();
  if (!session) {
    showNotification("LeetSync: Not logged in", "Please login to LeetCode first.");
    return;
  }

  try {
    // 1. Get problem info (difficulty, id, title)
    const info = await fetchProblemInfo(titleSlug, session, csrf);
    if (!info) { showNotification("LeetSync: Error", "Could not fetch problem info."); return; }

    // 2. Get code — prefer from API (more reliable than DOM scraping)
    let code = await fetchLatestAcceptedCode(titleSlug, session, csrf);
    if (!code) code = pageCode; // fallback to DOM scraped code
    if (!code) { showNotification("LeetSync: No code found", "Could not capture solution code."); return; }

    // 3. Ensure repo exists
    await ensureRepo(token, username, repo);

    // 4. Build file
    const ext = LANG_EXT[lang] || lang;
    const safe = info.title.replace(/[^a-zA-Z0-9]/g, "_");
    const filename = `${info.id}.${safe}.${ext}`;
    const folder = info.difficulty; // Easy / Medium / Hard

    const header = [
      `/**`,
      ` * #${info.id} — ${info.title}`,
      ` * Difficulty : ${info.difficulty}`,
      ` * Language   : ${lang}`,
      ` * URL        : https://leetcode.com/problems/${titleSlug}/`,
      ` * Synced by  : LeetSync Pro`,
      ` */`,
      ``, ``
    ].join("\n");

    // 5. Push solution file to GitHub
    const ok = await pushToGitHub(token, username, repo, folder, filename, header + code,
      `Add ${info.id}. ${info.title} (${info.difficulty})`
    );

    if (ok) {
      // Save last synced info
      const { syncedCount = 0 } = await browser.storage.local.get("syncedCount");
      const newCount = syncedCount + 1;
      await browser.storage.local.set({ syncedCount: newCount, lastSynced: info.title });

      // 6. Update README
      await updateReadme(token, username, repo, {
        id: info.id, title: info.title, difficulty: info.difficulty,
        lang, ext, safe, filename
      });

      showNotification(
        `✔ Synced: ${info.title}`,
        `${info.difficulty} · README updated · github.com/${username}/${repo}`
      );
    } else {
      showNotification("LeetSync: Push failed", "GitHub push failed. Check your token.");
    }

  } catch (err) {
    console.error("[LeetSync]", err);
    showNotification("LeetSync: Error", err.message);
  }
}

async function testConnection() {
  const token = await getGitHubToken();
  if (!token) return { ok: false, msg: "No GitHub token set" };

  const { username, repo } = await getRepoConfig();
  const res = await fetch(`https://api.github.com/user`, {
    headers: { Authorization: `token ${token}`, Accept: "application/vnd.github.v3+json" },
  });

  if (res.ok) {
    const user = await res.json();
    await browser.storage.local.set({ githubUsername: user.login });
    return { ok: true, msg: `Connected as ${user.login}` };
  }
  return { ok: false, msg: `GitHub error ${res.status}` };
}

async function getStatus() {
  const { syncedCount = 0, lastSynced = null, githubUsername, githubRepo } = 
    await browser.storage.local.get(["syncedCount", "lastSynced", "githubUsername", "githubRepo"]);
  const token = await getGitHubToken();
  return { connected: !!token, syncedCount, lastSynced, githubUsername, githubRepo };
}

function showNotification(title, message) {
  browser.notifications.create({
    type: "basic",
    iconUrl: "icons/icon48.png",
    title,
    message,
  });
}

// ── README updater ────────────────────────────────────────────────────────────

async function updateReadme(token, username, repo, newProblem) {
  const apiUrl = `https://api.github.com/repos/${username}/${repo}/contents/README.md`;
  const headers = { Authorization: `token ${token}`, Accept: "application/vnd.github.v3+json" };

  // Fetch existing README
  const checkRes = await fetch(apiUrl, { headers });
  let existingSha = null;
  let existingProblems = [];
  let stats = { Easy: 0, Medium: 0, Hard: 0 };

  if (checkRes.ok) {
    const data = await checkRes.json();
    existingSha = data.sha;
    const content = decodeURIComponent(escape(atob(data.content.replace(/\n/g, ""))));

    // Parse existing table rows
    const rows = content.match(/\| \d+ \| \[.+?\].+?\|.+?\|.+?\|/g) || [];
    for (const row of rows) {
      const m = row.match(/\| (\d+) \| \[(.+?)\].*?\| [^\|]+ (\w+) \| (.+?) \|/);
      if (m) {
        const difficulty = m[3];
        existingProblems.push({ id: m[1], title: m[2], difficulty, lang: m[4].trim() });
        if (stats[difficulty] !== undefined) stats[difficulty]++;
      }
    }
  }

  // Add new problem if not already listed
  if (!existingProblems.find(p => p.id === newProblem.id)) {
    existingProblems.push(newProblem);
    if (stats[newProblem.difficulty] !== undefined) stats[newProblem.difficulty]++;
  }

  const LEXT = {
    cpp: "cpp", cplusplus: "cpp", java: "java", python: "py", python3: "py",
    javascript: "js", typescript: "ts", csharp: "cs", c: "c",
    ruby: "rb", swift: "swift", golang: "go", kotlin: "kt", rust: "rs", php: "php", mysql: "sql",
  };

  const date = new Date().toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
  const total = (stats.Easy||0) + (stats.Medium||0) + (stats.Hard||0);

  const tableRows = existingProblems
    .sort((a, b) => parseInt(a.id) - parseInt(b.id))
    .map(p => {
      const badge = { Easy: "🟢", Medium: "🟡", Hard: "🔴" }[p.difficulty] || "⚪";
      const ext = LEXT[(p.lang||"cpp").toLowerCase()] || "cpp";
      const safe = p.title.replace(/[^a-zA-Z0-9]/g, "_");
      return `| ${p.id} | [${p.title}](${p.difficulty}/${p.id}.${safe}.${ext}) | ${badge} ${p.difficulty} | ${(p.lang||"").toUpperCase()} |`;
    });

  const readme = [
    `# 📘 LeetCode Solutions`,
    `> Auto-synced by LeetSync Pro · Last updated: ${date}`,
    ``,
    `## 📊 Stats`,
    `| 🟢 Easy | 🟡 Medium | 🔴 Hard | Total |`,
    `|---------|----------|--------|-------|`,
    `| ${stats.Easy||0} | ${stats.Medium||0} | ${stats.Hard||0} | ${total} |`,
    ``,
    `## 📁 Solutions`,
    `| # | Problem | Difficulty | Language |`,
    `|---|---------|-----------|----------|`,
    ...tableRows,
  ].join("\n");

  await fetch(apiUrl, {
    method: "PUT",
    headers: { ...headers, "Content-Type": "application/json" },
    body: JSON.stringify({
      message: `Update README — ${newProblem.id}. ${newProblem.title} added`,
      content: btoa(unescape(encodeURIComponent(readme))),
      ...(existingSha ? { sha: existingSha } : {}),
    }),
  });
}
