const tokenEl   = document.getElementById("gh-token");
const repoEl    = document.getElementById("gh-repo");
const saveBtn   = document.getElementById("save-btn");
const alertEl   = document.getElementById("alert");
const statusBar = document.getElementById("status-bar");
const statusTxt = document.getElementById("status-text");
const repoLink  = document.getElementById("repo-link");
const footerL   = document.getElementById("footer-left");
const lastSync  = document.getElementById("last-sync");
const lastName  = document.getElementById("last-sync-name");
const cntEasy   = document.getElementById("cnt-easy");
const cntMed    = document.getElementById("cnt-med");
const cntHard   = document.getElementById("cnt-hard");

async function loadStats(username, repo, token) {
  if (!username || !repo || !token) return;

  try {
    // Fetch README from GitHub and parse stats
    const res = await fetch(`https://api.github.com/repos/${username}/${repo}/contents/README.md`, {
      headers: { Authorization: `token ${token}`, Accept: "application/vnd.github.v3+json" }
    });

    if (!res.ok) return;
    const data = await res.json();
    const content = decodeURIComponent(escape(atob(data.content.replace(/\n/g, ""))));

    // Count Easy/Medium/Hard from table rows
    const easyCount   = (content.match(/🟢 Easy/g) || []).length - 1;   // -1 for header
    const medCount    = (content.match(/🟡 Medium/g) || []).length - 1;
    const hardCount   = (content.match(/🔴 Hard/g) || []).length - 1;

    // Also try parsing from stats table line
    const statsLine = content.match(/\| (\d+) \| (\d+) \| (\d+) \| \d+ \|/);
    if (statsLine) {
      cntEasy.textContent = statsLine[1];
      cntMed.textContent  = statsLine[2];
      cntHard.textContent = statsLine[3];
    } else {
      cntEasy.textContent = Math.max(0, easyCount);
      cntMed.textContent  = Math.max(0, medCount);
      cntHard.textContent = Math.max(0, hardCount);
    }
  } catch (e) {
    console.error("Stats fetch error:", e);
  }
}

// Load on open
(async () => {
  const status = await browser.runtime.sendMessage({ type: "GET_STATUS" });
  const { githubToken } = await browser.storage.local.get("githubToken");

  if (status.connected) {
    statusBar.className = "status-bar connected";
    statusTxt.textContent = `Connected as ${status.githubUsername || "GitHub"}`;

    if (status.githubRepo) {
      repoEl.value = status.githubRepo;
      repoLink.href = `https://github.com/${status.githubUsername}/${status.githubRepo}`;
      repoLink.style.display = "inline";
    }

    if (status.syncedCount > 0) {
      footerL.textContent = `${status.syncedCount} solutions synced this session`;
    }

    if (status.lastSynced) {
      lastSync.style.display = "block";
      lastName.textContent = status.lastSynced;
    }

    // Load stats from GitHub repo
    await loadStats(status.githubUsername, status.githubRepo, githubToken);
  }

  if (githubToken) tokenEl.placeholder = "••••••••••••••••••••";
})();

saveBtn.addEventListener("click", async () => {
  const token = tokenEl.value.trim();
  const repo  = repoEl.value.trim() || "leetcode-solutions";

  if (!token && !tokenEl.placeholder.includes("•")) {
    showAlert("err", "GitHub token zaroori hai. github.com/settings/tokens se banao.");
    return;
  }

  saveBtn.textContent = "Connecting...";
  saveBtn.disabled = true;

  await browser.storage.local.set({ githubRepo: repo });
  if (token) await browser.storage.local.set({ githubToken: token });

  const result = await browser.runtime.sendMessage({ type: "TEST_CONNECTION" });

  saveBtn.textContent = "Connect GitHub";
  saveBtn.disabled = false;

  if (result?.ok) {
    showAlert("ok", `✔ ${result.msg} · Repo: ${repo}`);
    statusBar.className = "status-bar connected";
    statusTxt.textContent = result.msg;
    repoLink.href = `https://github.com/${result.githubUsername || ""}/${repo}`;
    repoLink.style.display = "inline";
    tokenEl.value = "";
    tokenEl.placeholder = "••••••••••••••••••••";

    // Load stats after connecting
    const { githubToken } = await browser.storage.local.get("githubToken");
    await loadStats(result.githubUsername, repo, token || githubToken);
  } else {
    showAlert("err", `✘ ${result?.msg || "Connection failed."}`);
    statusBar.className = "status-bar error";
    statusTxt.textContent = "Connection failed";
  }
});

function showAlert(type, msg) {
  alertEl.className = `alert ${type}`;
  alertEl.textContent = msg;
}
