/**
 * LeetSync Pro — Content Script
 * Watches for Accepted submissions on LeetCode problem pages
 */
(function () {
  let lastSynced = null;

  // Watch DOM for submission result
  const observer = new MutationObserver(() => {
    const resultEl = document.querySelector('[data-e2e-locator="submission-result"]');
    if (resultEl && resultEl.textContent.trim() === "Accepted") {
      const key = location.href + resultEl.textContent;
      if (key !== lastSynced) {
        lastSynced = key;
        setTimeout(captureAndSync, 1200);
      }
    }
  });

  observer.observe(document.body, { subtree: true, childList: true, characterData: true });

  // Also check on load (if navigating directly to a submission result)
  setTimeout(() => {
    const resultEl = document.querySelector('[data-e2e-locator="submission-result"]');
    if (resultEl && resultEl.textContent.trim() === "Accepted") {
      captureAndSync();
    }
  }, 2000);

  function getCode() {
    // Try Monaco editor lines
    const lines = document.querySelectorAll(".view-line");
    if (lines.length > 0) {
      return Array.from(lines).map(l => l.innerText).join("\n");
    }
    // Try CodeMirror
    const cm = document.querySelector(".CodeMirror");
    if (cm?.CodeMirror) return cm.CodeMirror.getValue();
    return null;
  }

  function getLang() {
    // Various selectors LeetCode uses for language selector
    const selectors = [
      '[id*="headlessui-listbox-button"] span',
      '.ant-select-selection-item',
      '[data-cy="lang-select"] span',
      'button[aria-haspopup="listbox"] span',
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (el?.textContent?.trim()) return el.textContent.trim();
    }
    return "cpp";
  }

  function getTitleSlug() {
    const match = location.href.match(/\/problems\/([^/]+)/);
    return match ? match[1] : null;
  }

  function captureAndSync() {
    const titleSlug = getTitleSlug();
    if (!titleSlug) return;

    const code = getCode();
    const lang = getLang().toLowerCase().replace(/\+/g, "p").replace(/\s/g, "").replace("#", "sharp");

    browser.runtime.sendMessage({
      type: "ACCEPTED_SOLUTION",
      payload: { titleSlug, code, lang }
    });
  }
})();
